`timescale 1ns/1ps

module uart_tx_tb;

reg clk;
reg rst;
reg tx_start;
reg [7:0] data_in;
wire tx;

uart_tx DUT (
    .clk(clk),
    .rst(rst),
    .tx_start(tx_start),
    .data_in(data_in),
    .tx(tx)
);

always #5 clk = ~clk;

initial begin
    $dumpfile("wave.vcd");
    $dumpvars(0, uart_tx_tb);

    clk = 0;
    rst = 1;
    tx_start = 0;
    data_in = 8'h00;

    #20 rst = 0;

    data_in = 8'h41; // A
    tx_start = 1;
    #10 tx_start = 0;

    #400;

    data_in = 8'h42; // B
    tx_start = 1;
    #10 tx_start = 0;

    #400;

    $finish;
end

endmodule
