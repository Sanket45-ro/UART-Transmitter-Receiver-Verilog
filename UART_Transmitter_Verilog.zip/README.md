# UART Transmitter in Verilog

Files:
- rtl/baud_gen.v
- rtl/uart_tx.v
- tb/uart_tx_tb.v

Simulation:
iverilog -o uart_sim rtl/*.v tb/*.v
vvp uart_sim

View waveform:
gtkwave wave.vcd
