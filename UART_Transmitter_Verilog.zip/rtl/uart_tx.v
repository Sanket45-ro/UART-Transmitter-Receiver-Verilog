module uart_tx(
    input clk,
    input rst,
    input tx_start,
    input [7:0] data_in,
    output reg tx
);

parameter CLKS_PER_BIT = 16;

wire tick;
baud_gen #(.CLKS_PER_BIT(CLKS_PER_BIT)) BG (
    .clk(clk),
    .rst(rst),
    .tick(tick)
);

localparam IDLE  = 2'b00;
localparam START = 2'b01;
localparam DATA  = 2'b10;
localparam STOP  = 2'b11;

reg [1:0] state;
reg [2:0] bit_index;
reg [7:0] data_reg;

always @(posedge clk or posedge rst) begin
    if (rst) begin
        state <= IDLE;
        tx <= 1'b1;
        bit_index <= 0;
        data_reg <= 0;
    end else begin
        case(state)
            IDLE: begin
                tx <= 1'b1;
                if (tx_start) begin
                    data_reg <= data_in;
                    state <= START;
                end
            end

            START: begin
                if (tick) begin
                    tx <= 1'b0;
                    bit_index <= 0;
                    state <= DATA;
                end
            end

            DATA: begin
                if (tick) begin
                    tx <= data_reg[bit_index];
                    if (bit_index == 7)
                        state <= STOP;
                    else
                        bit_index <= bit_index + 1;
                end
            end

            STOP: begin
                if (tick) begin
                    tx <= 1'b1;
                    state <= IDLE;
                end
            end
        endcase
    end
end

endmodule
