module baud_gen #(
    parameter CLKS_PER_BIT = 16
)(
    input clk,
    input rst,
    output reg tick
);

reg [15:0] count;

always @(posedge clk or posedge rst) begin
    if (rst) begin
        count <= 0;
        tick <= 0;
    end else begin
        if (count == CLKS_PER_BIT-1) begin
            count <= 0;
            tick <= 1;
        end else begin
            count <= count + 1;
            tick <= 0;
        end
    end
end

endmodule
